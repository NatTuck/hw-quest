How would the provided Rocket record need to change if the rocket could accelerate to the left and right
in addition to accelerating up? (Hint: Fields? Methods? Existing? New?)