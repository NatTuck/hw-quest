package demo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AppShould {

    @Test
    void add_two_numbers() {
	assertEquals(1 + 1, 2);
    }
}
