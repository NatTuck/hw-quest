package dslabs;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello, Demo");
    }

    /**
     * Add seven to an integer.
     *
     * @param  xx  The input.
     * @return     Seven more than the input.
     */
    public static int addSeven(int xx) {
        return xx + 7;
    }
}
