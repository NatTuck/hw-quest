package dslabs;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static dslabs.App.addSeven;

public class AppShould {

    @Test
    void add_seven() {
        assertEquals(10, addSeven(3));
        assertEquals(24, addSeven(17));
    }
}
